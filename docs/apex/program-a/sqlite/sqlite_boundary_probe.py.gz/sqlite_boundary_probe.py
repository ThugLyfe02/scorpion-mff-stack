"""Program A diagnostic: synthetic temporary DBs; no brokerage or network calls."""
from __future__ import annotations
import json
import sqlite3
import tempfile
from pathlib import Path
from datetime import UTC, datetime
from scorpion.store import Store
from scorpion.domain import RawDiscordMessage
from scorpion.durable_ingress import append_raw_with_receipt
from scorpion.processing_order import register_raw_receipt, load_signals_in_processing_order, load_pending_raw_in_receipt_order, inspect_processing_order
from scorpion.failure_quarantine import record_processing_failure, requeue_quarantined, load_quarantined
from scorpion.delivery import DeliveryLedger
from scorpion.integrity import IntegrityLedger
from scorpion.release_guard import ReleaseRegistry
from scorpion.fail_safe_control import NoTradeSafetyLatch
from scorpion.production_gate import ProductionGateRegistry
from scorpion.deployment_state_machine import DeploymentStateMachine
from scorpion.state_checkpoint import create_state_checkpoint
from scorpion.recovery import create_verified_backup

REAL_CONNECT = sqlite3.connect
KEYS = ('synchronous', 'foreign_keys', 'busy_timeout', 'journal_mode')
connections = []
class ObservedConnection(sqlite3.Connection):
    def capture(self):
        try:
            self.captured = {name: self.execute('PRAGMA ' + name).fetchone()[0] for name in KEYS}
        except sqlite3.ProgrammingError:
            pass
        return self.captured
    def close(self):
        self.capture()
        super().close()

def connect(*args, **kwargs):
    db = REAL_CONNECT(*args, **kwargs, factory=ObservedConnection)
    if weak:
        db.execute('PRAGMA synchronous=OFF')
        db.execute('PRAGMA foreign_keys=OFF')
        db.execute('PRAGMA busy_timeout=1')
    db.captured = {}
    connections.append(db)
    return db

def settings(f):
    connections.clear()
    error = None
    try:
        f()
    except Exception as e:
        error = type(e).__name__ + ': ' + str(e)
    result = [db.capture() for db in connections]
    for db in connections:
        db.close()
    unique = [dict(x) for x in dict.fromkeys(tuple(x.items()) for x in result)]
    return {'connections': len(result), 'settings': unique, 'error': error}

payload = {'sqlite_version': sqlite3.sqlite_version, 'cases': {}}
for weak in (False, True):
    with tempfile.TemporaryDirectory() as directory:
        root = Path(directory)
        p = root / 'runtime.db'
        store = Store(p)
        ts = datetime(2026,9,8,14,tzinfo=UTC)
        raw = RawDiscordMessage(message_id='pragma-probe',guild_id='912747256736800838',channel_id='968352649437126676',author_id='synthetic',content='synthetic non-authoritative diagnostic',source_ts_utc=ts,received_ts_utc=ts)
        store.append_raw(raw)
        sqlite3.connect = connect
        results = {}
        try:
            def store_write():
                with store.connect() as db:
                    db.execute('UPDATE runtime_flags SET value=value WHERE key=?', ('halted',))
            results['Store.connect'] = settings(store_write)
            results['append_raw_with_receipt'] = settings(lambda: append_raw_with_receipt(p, raw))
            results['register_raw_receipt'] = settings(lambda: register_raw_receipt(p,raw.revision_id))
            results['load_signals_in_processing_order'] = settings(lambda:load_signals_in_processing_order(p))
            results['load_pending_raw_in_receipt_order'] = settings(lambda:load_pending_raw_in_receipt_order(p))
            results['inspect_processing_order'] = settings(lambda:inspect_processing_order(p))
            results['record_processing_failure'] = settings(lambda:record_processing_failure(p,raw.revision_id,'synthetic',maximum_attempts=1))
            results['load_quarantined'] = settings(lambda:load_quarantined(p))
            results['requeue_quarantined'] = settings(lambda:requeue_quarantined(p,raw.revision_id,operator='diagnostic',note='synthetic'))
            delivery = DeliveryLedger(root/'delivery.db')
            results['DeliveryLedger.acquire'] = settings(lambda:delivery.acquire('absent',owner='diagnostic'))
            integrity = IntegrityLedger(root/'integrity.db')
            results['IntegrityLedger.append'] = settings(lambda:integrity.append('synthetic',{'kind':'diagnostic'}))
            registry = ReleaseRegistry(root/'release.db')
            results['ReleaseRegistry.register'] = settings(lambda:registry.register(component='diagnostic',artifact_hash='artifact',policy_fingerprint='policy',research_manifest_hash='manifest'))
            latch = NoTradeSafetyLatch(root/'latch.db')
            results['NoTradeSafetyLatch.trip_no_trade'] = settings(lambda:latch.trip_no_trade('diagnostic',reason='synthetic'))
            results['NoTradeSafetyLatch.clear_no_trade'] = settings(lambda:latch.clear_no_trade('diagnostic',operator='diagnostic',reason='synthetic'))
            results['ProductionGateRegistry.init'] = settings(lambda:ProductionGateRegistry(root/'production.db'))
            results['DeploymentStateMachine.init'] = settings(lambda:DeploymentStateMachine(root/'deployment.db'))
            results['create_state_checkpoint'] = settings(lambda:create_state_checkpoint(p))
            results['create_verified_backup'] = settings(lambda:create_verified_backup(p,root/'backup.db'))
        finally:
            sqlite3.connect = REAL_CONNECT
        payload['cases']['injected_weak_defaults' if weak else 'environment_defaults'] = results
print(json.dumps(payload, indent=2))
