#!/usr/bin/env python3
"""Offline Program A probe; no broker, network, deployment, or research models.

Run one capture per worktree/interpreter. Always pass the SAME golden fixture when
comparing heads. Timed mode must run sequentially, without concurrent tests.

  python apex_baseline_probe.py capture --repo /path/to/repo --out /tmp/pr3 \
      --golden /path/to/frozen/mff_golden.json --mode semantics
  python apex_baseline_probe.py capture --repo /path/to/repo --out /tmp/pr3-all \
      --golden /path/to/frozen/mff_golden.json --mode all --samples 320
  python apex_baseline_probe.py compare --before /tmp/pr3/baseline.json \
      --after /tmp/pr4/baseline.json --out /tmp/pr3-pr4-diff.json

Generated JSON is evidence, not a declaration that discrepancies are acceptable.
"""

from __future__ import annotations

import argparse
import asyncio
import dataclasses
import hashlib
import importlib
import json
import math
import os
import platform
import sqlite3
import subprocess
import sys
import tempfile
import time
from collections import Counter
from datetime import UTC, date, datetime, timedelta
from decimal import Decimal
from enum import Enum
from pathlib import Path
from typing import Any

VERSION = "apex-baseline-probe-v1"
FIXED_TIME = datetime(2026, 9, 8, 14, 0, tzinfo=UTC)
AUTHOR = "baseline-author"
GUILD = "912747256736800838"
CHANNEL = "968352649437126676"
ENTRY = "AAPL 200C Sep 11 @ 1.00"
CONTRACT = "AAPL|CALL|200|2026-09-11"


def normalized(value: Any) -> Any:
    if dataclasses.is_dataclass(value) and not isinstance(value, type):
        return {f.name: normalized(getattr(value, f.name)) for f in dataclasses.fields(value)}
    if isinstance(value, Enum):
        return normalized(value.value)
    if isinstance(value, (datetime, date)):
        return value.isoformat()
    if isinstance(value, Decimal):
        return str(value)
    if isinstance(value, Path):
        return str(value)
    if isinstance(value, dict):
        return {str(k): normalized(v) for k, v in sorted(value.items(), key=lambda kv: str(kv[0]))}
    if isinstance(value, (set, frozenset)):
        return sorted((normalized(v) for v in value), key=canonical)
    if isinstance(value, (list, tuple)):
        return [normalized(v) for v in value]
    if value is None or isinstance(value, (str, bool, int, float)):
        return value
    raise TypeError(f"unhandled evidence type: {type(value).__name__}")


def canonical(value: Any) -> str:
    return json.dumps(normalized(value), sort_keys=True, separators=(",", ":"), allow_nan=False)


def digest(value: Any) -> str:
    return hashlib.sha256(canonical(value).encode()).hexdigest()


def file_hash(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(normalized(value), indent=2, sort_keys=True, allow_nan=False) + "\n")


def git(repo: Path, *args: str) -> str:
    return subprocess.check_output(["git", "-C", str(repo), *args], text=True).strip()


def msg(text: str, message_id: str, **kwargs: Any) -> dict[str, Any]:
    return {"op": "raw", "text": text, "message_id": message_id, **kwargs}


def corpus(golden: Path) -> list[dict[str, Any]]:
    rows = json.loads(golden.read_text())
    cases = [
        {"id": f"golden_{i:03}", "expected_parser_kind": row["kind"],
         "steps": [msg(row["text"], f"golden-{i}")]}
        for i, row in enumerate(rows)
    ]
    singletons = {
        "blocked_channel": msg(ENTRY, "blocked-channel", channel_id="research-only-channel"),
        "blocked_author": msg(ENTRY, "blocked-author", author_id="unapproved-author"),
        "blocked_guild": msg(ENTRY, "blocked-guild", guild_id="unapproved-guild"),
        "excluded_nke": msg("NKE 42.5C Sep 11 @ 1.40", "nke"),
        "friday_entry": msg(ENTRY, "friday", source_offset_ms=259200000),
        "negated_entry": msg("Do not buy AAPL 200C Sep 11 @ 1.00", "neg-entry"),
        "negated_add": msg("Not adding here", "neg-add"),
        "negated_exit": msg("Do not close; still holding", "neg-exit"),
        "conditional_exit": msg("Ready to close if this loses VWAP", "conditional"),
        "malformed_expiry": msg("AAPL 200C 2026-02-30 @ 1.00", "invalid-expiry"),
        "unicode_spacing": msg("ＡＡＰＬ\u200b 200C Sep 11 @ 1.00", "unicode"),
    }
    cases.extend({"id": name, "steps": [step]} for name, step in singletons.items())
    fill = {"op": "fill", "contract_key": CONTRACT, "generation": 1,
            "quantity_delta": 10, "fill_price": "1.00"}
    scenarios = {
        "max_two_and_first_pipe": [msg(ENTRY, "a"), msg("NVDA 227.5P Sep 11 @ 2.63", "b"),
                                   msg("TSLA 390C Sep 11 @ 1.90", "c")],
        "duplicate_raw": [msg(ENTRY, "same", source_offset_ms=0),
                          msg(ENTRY, "same", source_offset_ms=0)],
        "duplicate_contract_new_message": [msg(ENTRY, "a"), msg(ENTRY, "b")],
        "add_only_once": [msg(ENTRY, "a"), fill, msg("Added at .85", "add-1"),
                          msg("Adding one more here", "add-2")],
        "repeated_trims": [msg(ENTRY, "a"), fill, msg("Closing half +20%", "trim-1"),
                           msg("Closing half +20%", "trim-2", source_offset_ms=3000),
                           msg("Closing half +20%", "trim-2", source_offset_ms=3000)],
        "fill_cost_basis_and_close": [msg(ENTRY, "a"), fill,
            {**fill, "quantity_delta": -5, "fill_price": "1.50"},
            {**fill, "quantity_delta": 5, "fill_price": "0.80"},
            msg("All out now", "exit"),
            {**fill, "quantity_delta": -10, "fill_price": "1.20", "final": True},
            msg(ENTRY, "late-entry")],
        "invalid_fill_generation": [msg(ENTRY, "a"), {**fill, "generation": 2,
            "expected_exception": {"type": "ValueError", "stage": "fill"}}],
        "invalid_negative_position": [msg(ENTRY, "a"), fill,
                                      {**fill, "quantity_delta": -11,
                                       "expected_exception": {"type": "ValueError", "stage": "fill"}}],
        "operator_stop_then_entry": [{"op": "normalized_stop", "event_id": "operator-stop"},
                                     msg(ENTRY, "after-stop")],
        "source_stop_loss_is_followup": [msg(ENTRY, "a"), msg("Stop loss hit", "stop-loss")],
        "edit_same_source_event": [msg(ENTRY, "edited", source_offset_ms=0),
            msg("AAPL 201C Sep 11 @ 1.20", "edited", source_offset_ms=0,
                receive_offset_ms=1000, edited_offset_ms=1000)],
        "reply_disambiguates_two_positions": [msg(ENTRY, "a"),
            msg("NVDA 227.5P Sep 11 @ 2.63", "b"),
            msg("Closing half +20%", "reply", referenced_message_id="a")],
        "unassociated_followup": [msg("Closing runners 19%+", "no-position")],
        "out_of_order_input": [msg(ENTRY, "entry", source_offset_ms=1000,
                                   receive_offset_ms=1000),
            msg("Closing half +20%", "late-older", source_offset_ms=0,
                receive_offset_ms=2000, referenced_message_id="entry")],
    }
    cases.extend({"id": name, "steps": steps} for name, steps in scenarios.items())
    return cases


def make_raw(domain: Any, case_id: str, index: int, step: dict[str, Any]) -> Any:
    source_offset = step.get("source_offset_ms", index * 1000)
    received_offset = step.get("receive_offset_ms", source_offset)
    ref = step.get("referenced_message_id")
    return domain.RawDiscordMessage(
        message_id=f"{case_id}:{step['message_id']}", guild_id=step.get("guild_id", GUILD),
        channel_id=step.get("channel_id", CHANNEL), author_id=step.get("author_id", AUTHOR),
        content=step["text"], source_ts_utc=FIXED_TIME + timedelta(milliseconds=source_offset),
        received_ts_utc=FIXED_TIME + timedelta(milliseconds=received_offset),
        edited_ts_utc=(FIXED_TIME + timedelta(milliseconds=step["edited_offset_ms"])
                       if "edited_offset_ms" in step else None),
        referenced_message_id=f"{case_id}:{ref}" if ref else None,
    )


def effects_multiset(effects: list[Any] | tuple[Any, ...]) -> list[dict[str, Any]]:
    counts = Counter(canonical(e) for e in effects)
    return [{"effect": json.loads(effect), "count": count} for effect, count in sorted(counts.items())]


def snapshot(state: Any, replay_module: Any) -> dict[str, Any]:
    return {"state": normalized(state), "canonical_sha256": digest(state),
            "native_state_fingerprint": replay_module.state_fingerprint(state)}


def semantic_case(case: dict[str, Any], modules: dict[str, Any], db: Path) -> dict[str, Any]:
    domain, parser, reducer, association, replay = (modules[n] for n in
        ("domain", "parser", "reducer", "association", "replay"))
    state = domain.BookState()
    semantic_store = modules["store"].Store(db)
    events, effects, steps, exclusions = [], [], [], []
    for i, spec in enumerate(case["steps"]):
        step: dict[str, Any] = {"index": i, "input": spec, "state_before": normalized(state)}
        stage = "input_validation"
        try:
            if spec["op"] == "fill":
                stage = "fill"
                state = reducer.apply_fill(state, contract_key=spec["contract_key"],
                    generation=spec["generation"], quantity_delta=spec["quantity_delta"],
                    fill_price=Decimal(spec["fill_price"]), final=spec.get("final", False))
                step["fill_result"] = "APPLIED_SYNTHETIC_FILL"
            else:
                if spec["op"] == "normalized_stop":
                    event = domain.SignalEvent(event_id=f"{case['id']}:{spec['event_id']}",
                        message_id=f"{case['id']}:operator", kind=domain.EventKind.STOP,
                        channel_id=CHANNEL, author_id=AUTHOR,
                        source_ts_utc=FIXED_TIME, received_ts_utc=FIXED_TIME,
                        raw_text="", reason="synthetic_operator_stop_fixture")
                    step["input_surface"] = "NORMALIZED_OPERATOR_EVENT_NOT_DISCORD_PARSE"
                else:
                    raw = make_raw(domain, case["id"], i, spec)
                    stage = "parse"
                    parsed = parser.parse_message_with_evidence(raw, frozenset({AUTHOR}))
                    step["raw"] = normalized(raw)
                    step["raw_revision_id"] = raw.revision_id
                    step["parsed_event"] = normalized(parsed.event)
                    step["parsed_contract_key"] = parsed.event.contract_key
                    evidence = normalized(parsed.evidence)
                    evidence.pop("latency_us", None)
                    exclusions.append(f"steps[{i}].parser_evidence.latency_us")
                    step["parser_evidence"] = evidence
                    stage = "association"
                    ref = (semantic_store.contract_for_message(raw.referenced_message_id)
                           if raw.referenced_message_id else None)
                    associated = association.associate_followup_with_evidence(parsed.event, state, ref)
                    step["association_evidence"] = normalized(associated.evidence)
                    event = associated.event
                step["associated_event"] = normalized(event)
                step["associated_contract_key"] = event.contract_key
                stage = "reduce"
                state, produced = reducer.reduce_book(state, event)
                effects.extend(produced)
                step["effects"] = normalized(produced)
                step["effect_multiset"] = effects_multiset(produced)
                stage = "durable_semantic_event"
                inserted = semantic_store.append_signal(event)
                step["persisted_signal_inserted"] = inserted
                if inserted:
                    events.append(event)
            stage = "invariant"
            modules["invariants"].assert_valid_book(state)
        except Exception as exc:
            step["exception"] = {"type": type(exc).__name__, "message": str(exc), "stage": stage}
            step["expected_rejection"] = spec.get("expected_exception") == {
                "type": type(exc).__name__, "stage": stage}
        if "expected_exception" in spec and "exception" not in step:
            step["expected_rejection_missing"] = True
        step["state_after"] = snapshot(state, replay)
        steps.append(step)
    native: dict[str, Any] = {}
    if any(s["op"] == "fill" for s in case["steps"]):
        native = {"status": "NOT_APPLICABLE", "reason": "normalized event replay has no fill events"}
    else:
        for name, kwargs in (("default_order", {}), ("input_order", {"order": "INPUT"})):
            if name == "input_order" and not hasattr(replay, "ReplayOrder"):
                native[name] = {"status": "UNAVAILABLE_IN_THIS_HEAD"}
                continue
            try:
                if kwargs:
                    kwargs = {"order": replay.ReplayOrder.INPUT}
                replay_state, replay_effects = replay.replay(events, **kwargs)
                native[name] = {"state": snapshot(replay_state, replay),
                                "ordered_effects": normalized(replay_effects),
                                "effect_multiset": effects_multiset(replay_effects)}
            except Exception as exc:
                native[name] = {"exception": {"type": type(exc).__name__, "message": str(exc)}}
    result = {"id": case["id"], "fixture": case, "steps": steps,
              "final_state": snapshot(state, replay), "effect_multiset": effects_multiset(effects),
              "ordered_effects": normalized(effects),
              "native_replay": native, "excluded_nondeterministic_fields": exclusions}
    unexpected = [s["index"] for s in steps if "exception" in s and not s["expected_rejection"]]
    missing = [s["index"] for s in steps if s.get("expected_rejection_missing")]
    result["unexpected_exception_steps"] = unexpected
    result["expected_rejection_missing_steps"] = missing
    result["normalized_replay_input_complete"] = not any(
        "exception" in s and s["exception"]["stage"] in {
            "input_validation", "parse", "association", "reduce", "durable_semantic_event"}
        for s in steps)
    result["semantic_status"] = ("INCOMPLETE_UNEXPECTED_EXCEPTION" if unexpected else
                                 "EXPECTED_REJECTION_NOT_OBSERVED" if missing else "COMPLETE")
    if "expected_parser_kind" in case:
        actual = steps[0].get("parsed_event", {}).get("kind")
        result["golden_kind_matches"] = actual == case["expected_parser_kind"]
        if not result["golden_kind_matches"]:
            result["semantic_status"] = "GOLDEN_KIND_MISMATCH"
    return result


def environment(workspace: Path) -> dict[str, Any]:
    cpu = "UNKNOWN"
    cpuinfo = Path("/proc/cpuinfo")
    if cpuinfo.exists():
        cpu = next((line.split(":", 1)[1].strip() for line in cpuinfo.read_text().splitlines()
                    if line.startswith("model name")), "UNKNOWN")
    fs = os.statvfs(workspace)
    try:
        mount = json.loads(subprocess.check_output(
            ["findmnt", "-J", "-T", str(workspace), "-o", "TARGET,SOURCE,FSTYPE"], text=True))
    except (OSError, subprocess.SubprocessError, ValueError):
        mount = {"status": "UNKNOWN"}
    return {"cpu_model": cpu, "logical_cpus": os.cpu_count(),
            "affinity_cpus": sorted(os.sched_getaffinity(0)) if hasattr(os, "sched_getaffinity") else None,
            "platform": platform.platform(), "machine": platform.machine(), "python": sys.version,
            "python_executable": sys.executable, "sqlite": sqlite3.sqlite_version,
            "clock": normalized(vars(time.get_clock_info("perf_counter"))),
            "load_average": os.getloadavg() if hasattr(os, "getloadavg") else None,
            "storage": {"mount": mount, "device_id": os.stat(workspace).st_dev,
                        "block_size": fs.f_frsize, "total_bytes": fs.f_blocks * fs.f_frsize,
                        "available_bytes": fs.f_bavail * fs.f_frsize,
                        "physical_media": "UNKNOWN_UNLESS_EXPOSED_BY_MOUNT_SOURCE"},
            "external_workload": "NOT_MEASURED; run without concurrent tests or benchmarks"}


def percentiles_ns(values: list[int]) -> dict[str, Any]:
    ordered = sorted(values)
    if not ordered:
        return {"samples": 0, "status": "INSUFFICIENT"}
    result = {"samples": len(values), "unit": "microseconds",
              "method": "nearest_rank: sorted[ceil(q*n)-1]", "max": max(values) / 1000}
    for label, q in (("p50", .50), ("p90", .90), ("p95", .95), ("p99", .99), ("p99.9", .999)):
        result[label] = ordered[max(0, math.ceil(q * len(ordered)) - 1)] / 1000
    result["tail_resolution_note"] = "At 300-999 samples p99.9 equals max; not a stable tail estimate"
    return result


async def comparable_pipeline_benchmark(modules: dict[str, Any], db: Path, samples: int) -> dict[str, Any]:
    store = modules["store"].Store(db)
    pipeline = modules["pipeline"].Pipeline(store, allowed_author_ids=frozenset({AUTHOR}))
    sentinel = getattr(pipeline, "integrity_sentinel", None)
    sentinel_before = getattr(sentinel, "_successful_commits", None)
    durations = []
    for i in range(samples):
        raw = make_raw(modules["domain"], "durable-benchmark", i,
                       msg(ENTRY, str(i), channel_id="baseline-non-execution-channel"))
        started = time.perf_counter_ns()
        event, effects = await pipeline.handle(raw)
        durations.append(time.perf_counter_ns() - started)
        if event.kind.value != "IGNORE" or effects:
            raise RuntimeError("non-execution benchmark unexpectedly produced actionable evidence")
    with store.connect() as connection:
        pragmas = {name: connection.execute(f"PRAGMA {name}").fetchone()[0]
                   for name in ("journal_mode", "synchronous", "foreign_keys", "busy_timeout")}
        counts = {name: connection.execute(f"SELECT COUNT(*) FROM {name}").fetchone()[0]
                  for name in ("raw_discord_events", "signal_events", "proposed_effects")}
    counts_match = counts == {"raw_discord_events": samples, "signal_events": samples,
                             "proposed_effects": 0}
    return {"status": "VALID_WORKLOAD" if counts_match else "INVALID_DURABLE_COUNTS",
            "measurement": "await Pipeline.handle from call to durable return; perf_counter_ns",
            "workload": "valid guild/author, rejected channel, distinct raw revisions, no positions",
            "excluded_costs": ["Pipeline/Store startup", "broker/network", "market quotes"],
            "warmup_samples": 0, "includes_first_use_cost": True,
            "sentinel_observation": {"present": sentinel is not None,
                "successful_commits_before": sentinel_before,
                "successful_commits_after": getattr(sentinel, "_successful_commits", None),
                "cadence_commits": getattr(sentinel, "every_n_commits", None),
                "scope": "actual pipeline sentinel object/counters; missing sentinel is not silently assumed"},
            "distribution": percentiles_ns(durations), "durations_ns": durations,
            "store_connection_pragmas": pragmas, "durable_counts": counts,
            "pragma_scope": "one actual Store.connect connection after the loop; other connection sites require separate verification",
            "counts_match": counts_match,
            "final_state": snapshot(pipeline.state, modules["replay"])}


def comparable_core_benchmark(modules: dict[str, Any], samples: int) -> dict[str, Any]:
    """Same valid-guild, pure-compute corpus on old and new implementations."""
    state = modules["domain"].BookState()
    policy = modules["config"].DEFAULT_POLICY
    templates = ("QQQ 719C TODAY @ 1.01", "Printing +19%", "NKE 42.5C Sep 11 @ 1.40")
    durations: list[int] = []
    kinds: Counter[str] = Counter()
    for index in range(samples):
        raw = make_raw(modules["domain"], "core-benchmark", index,
                       msg(templates[index % len(templates)], str(index)))
        started = time.perf_counter_ns()
        parsed = modules["parser"].parse_message_with_evidence(raw, frozenset({AUTHOR}))
        associated = modules["association"].associate_followup_with_evidence(parsed.event, state, None)
        state, _ = modules["reducer"].reduce_book(state, associated.event, policy)
        modules["invariants"].assert_valid_book(state, max_open_positions=policy.max_open_positions)
        durations.append(time.perf_counter_ns() - started)
        kinds[associated.event.kind.value] += 1
    expected = Counter(("ENTRY", "AMBIGUOUS", "IGNORE")[i % 3] for i in range(samples))
    if kinds != expected:
        raise RuntimeError(f"core benchmark classification changed: {dict(kinds)} != {dict(expected)}")
    return {"status": "VALID_WORKLOAD", "measurement": "parse/association/reduce/invariant compute; perf_counter_ns",
            "workload": "valid guild/author/channel; fixed entry/followup/rejection templates",
            "excluded_costs": ["durable ingress", "decision packet admission", "quotes", "broker/network"],
            "policy_scope": "DEFAULT_POLICY normalized source reducer, not execution eligibility",
            "warmup_samples": 0, "event_kind_counts": dict(sorted(kinds.items())),
            "distribution": percentiles_ns(durations), "durations_ns": durations,
            "final_state": snapshot(state, modules["replay"])}


def benchmarks(repo: Path, out: Path, modules: dict[str, Any], samples: int) -> dict[str, Any]:
    if samples < 300:
        raise ValueError("benchmark samples must be >=300")
    # All stages are sequential; callers must also avoid external benchmark/test concurrency.
    with tempfile.TemporaryDirectory(prefix="apex-baseline-db-", dir=out) as temporary:
        workspace = Path(temporary)
        before = environment(workspace)
        core = comparable_core_benchmark(modules, samples)
        full = asyncio.run(comparable_pipeline_benchmark(modules, workspace / "durable.db", samples))
        native: dict[str, Any] = {"status": "UNAVAILABLE_IN_THIS_HEAD"}
        if (repo / "src/scorpion/hot_path_benchmark.py").exists():
            module = importlib.import_module("scorpion.hot_path_benchmark")
            report = module.benchmark_hot_path(samples=samples, workspace=workspace, now=FIXED_TIME)
            native = {"status": "EXECUTED", "report": normalized(report),
                      "method": "unmodified existing benchmark_hot_path API",
                      "source_sha256": file_hash(repo / "src/scorpion/hot_path_benchmark.py"),
                      "limitations": ["native report exposes p50/p95/p99/max only",
                        "native synthetic guild must be checked before interpreting core parser cost",
                        "native synchronous PRAGMA is read from a separate bare sqlite3 connection; not a writer attestation"]}
            native["fixture_guild_matches_runtime"] = (
                module._message(index=0, when=FIXED_TIME, content=ENTRY).guild_id == GUILD)
        return {"environment_before": before, "environment_after": environment(workspace),
                "comparable_core_compute": core,
                "comparable_durable_pipeline": full, "native_hot_path_benchmark": native}


def capture(args: argparse.Namespace) -> int:
    repo, out = args.repo.resolve(), args.out.resolve()
    out.mkdir(parents=True, exist_ok=True)
    if any(name == "scorpion" or name.startswith("scorpion.") for name in sys.modules):
        raise RuntimeError("capture must start in a fresh interpreter")
    sys.path.insert(0, str(repo / "src"))
    package = importlib.import_module("scorpion")
    if Path(package.__file__).resolve().parent != (repo / "src/scorpion").resolve():
        raise RuntimeError("import origin does not match requested worktree")
    names = ("domain", "parser", "association", "reducer", "replay", "invariants", "config",
             "store", "pipeline")
    modules = {name: importlib.import_module(f"scorpion.{name}") for name in names}
    sources = {str(p.relative_to(repo)): file_hash(p)
               for p in sorted((repo / "src/scorpion").rglob("*.py"))}
    locked = repo / "live/RULES.lock.md"
    sources["live/RULES.lock.md"] = file_hash(locked)
    runtime_policy: dict[str, Any] = {"scope": "DEFAULT_POLICY only; no RuntimePolicyBundle in head",
                                    "payload": normalized(modules["config"].DEFAULT_POLICY)}
    if (repo / "src/scorpion/policy_bundle.py").exists():
        bundle = importlib.import_module("scorpion.policy_bundle").RuntimePolicyBundle()
        runtime_policy = {"scope": "RuntimePolicyBundle", "payload": normalized(bundle),
                          "native_fingerprint": bundle.fingerprint}
    golden = args.golden.resolve() if args.golden else repo / "tests/fixtures/mff_golden.json"
    cases = corpus(golden)
    report: dict[str, Any] = {
        "probe_version": VERSION, "probe_sha256": file_hash(Path(__file__).resolve()),
        "mode": args.mode, "source": {"repo": str(repo), "head_sha": git(repo, "rev-parse", "HEAD"),
            "tree_sha": git(repo, "rev-parse", "HEAD^{tree}"),
            "tracked_changes": git(repo, "status", "--porcelain=v1", "--untracked-files=no"),
            "file_sha256": sources, "source_manifest_sha256": digest(sources),
            "strategy_sha256": sources["live/RULES.lock.md"],
            "parser_version": modules["parser"].PARSER_VERSION,
            "parser_source_sha256": sources["src/scorpion/parser.py"],
            "runtime_policy": runtime_policy, "runtime_policy_payload_sha256": digest(runtime_policy)},
        "fixture_time_utc": FIXED_TIME.isoformat(),
        "golden_fixture": {"path": str(golden), "sha256": file_hash(golden)},
        "corpus_sha256": digest(cases),
        "limits": ["synthetic/golden semantic certification is not empirical trading performance",
            "synthetic fills test reducer accounting, not fill feasibility",
            "source/default replay and input replay are recorded separately",
            "semantic association uses real Store append_signal/contract_for_message in isolated temporary stores",
            "semantic probe targets parser/association/reducer; admission, halt and dispatch need separate runtime invariant tests",
            "all event/effect/state fields retained; only parser-evidence latency_us excluded"],
    }
    if args.mode in {"semantics", "all"}:
        with tempfile.TemporaryDirectory(prefix="apex-semantic-stores-", dir=out) as temporary:
            results = [semantic_case(case, modules, Path(temporary) / f"{case['id']}.db")
                       for case in cases]
        for case in results:
            write_json(out / "cases" / f"{case['id']}.json", case)
        report["semantics"] = {"cases": results, "case_count": len(results),
                               "canonical_sha256": digest(results),
                               "status": "COMPLETE" if all(c["semantic_status"] == "COMPLETE"
                                                            for c in results) else "INCOMPLETE",
                               "incomplete_cases": [c["id"] for c in results
                                                    if c["semantic_status"] != "COMPLETE"],
                               "exception_steps": sum("exception" in s for c in results for s in c["steps"]),
                               "golden_mismatches": [c["id"] for c in results
                                                     if c.get("golden_kind_matches") is False]}
    if args.mode in {"benchmarks", "all"}:
        report["benchmarks"] = benchmarks(repo, out, modules, args.samples)
        write_json(out / "benchmark.json", report["benchmarks"])
    sources_after = {str(p.relative_to(repo)): file_hash(p)
                     for p in sorted((repo / "src/scorpion").rglob("*.py"))}
    sources_after["live/RULES.lock.md"] = file_hash(locked)
    report["source_stability"] = {
        "head_unchanged": git(repo, "rev-parse", "HEAD") == report["source"]["head_sha"],
        "source_files_unchanged": sources_after == sources,
        "golden_fixture_unchanged": file_hash(golden) == report["golden_fixture"]["sha256"],
        "probe_unchanged": file_hash(Path(__file__).resolve()) == report["probe_sha256"],
    }
    report["capture_status"] = ("VALID_CAPTURE" if all(report["source_stability"].values())
                                else "SOURCE_CHANGED_DURING_CAPTURE")
    write_json(out / "baseline.json", report)
    print(json.dumps({"artifact": str(out / "baseline.json"), "head_sha": report["source"]["head_sha"],
                      "mode": args.mode, "semantic_cases": report.get("semantics", {}).get("case_count"),
                      "semantic_status": report.get("semantics", {}).get("status"),
                      "incomplete_cases": report.get("semantics", {}).get("incomplete_cases"),
                      "capture_status": report["capture_status"],
                      "semantic_sha256": report.get("semantics", {}).get("canonical_sha256")}))
    if report["capture_status"] != "VALID_CAPTURE":
        return 2
    if ("benchmarks" in report
            and not report["benchmarks"]["comparable_durable_pipeline"]["counts_match"]):
        return 3
    return 0


def differences(before: Any, after: Any, path: str = "") -> list[dict[str, Any]]:
    if before == after:
        return []
    if isinstance(before, dict) and isinstance(after, dict):
        result = []
        for key in sorted(before.keys() | after.keys()):
            child = f"{path}.{key}" if path else str(key)
            if key not in before or key not in after:
                result.append({"path": child, "before": before.get(key), "after": after.get(key),
                               "presence_changed": True})
            else:
                result.extend(differences(before[key], after[key], child))
        return result
    if isinstance(before, list) and isinstance(after, list) and len(before) == len(after):
        return [change for i, (left, right) in enumerate(zip(before, after, strict=True))
                for change in differences(left, right, f"{path}[{i}]")]
    return [{"path": path, "before": before, "after": after}]


def category(change: dict[str, Any]) -> str:
    path = change["path"]
    if path.startswith("native_replay.input_order"):
        return "REPLAY_CAPABILITY_OR_ORDERING"
    if "exception" in path:
        return "EXCEPTION"
    if "effect" in path:
        return "EFFECT_IDENTITY" if path.endswith("source_event_id") else "EFFECT_SEMANTICS"
    if "parser_evidence" in path:
        return "PARSER_EVIDENCE"
    if "association_evidence" in path:
        return "ASSOCIATION"
    if any(s in path for s in ("event_id", "fingerprint", "sha256", "parser_version")):
        return "IDENTITY_OR_FINGERPRINT"
    if "parsed_event" in path or "associated_event" in path or "contract_key" in path:
        if path.endswith("kind"):
            return "PARSER_ACTION_CLASSIFICATION"
        return "EVENT_OR_CONTRACT_SEMANTICS"
    if "state" in path:
        return "STATE_SEMANTICS"
    if "fill" in path:
        return "FILL_SEMANTICS"
    if "native_replay" in path:
        return "REPLAY_CAPABILITY_OR_ORDERING"
    return "OTHER_REVIEW_REQUIRED"


def compare(args: argparse.Namespace) -> int:
    before, after = (json.loads(p.read_text()) for p in (args.before, args.after))
    if "semantics" not in before or "semantics" not in after:
        raise ValueError("comparison requires semantic captures")
    same_corpus = before["corpus_sha256"] == after["corpus_sha256"]
    same_probe = before["probe_sha256"] == after["probe_sha256"]
    stable_sources = all(r.get("capture_status") == "VALID_CAPTURE" for r in (before, after))
    complete = all(r["semantics"].get("status") == "COMPLETE" for r in (before, after))
    left = {c["id"]: c for c in before["semantics"]["cases"]}
    right = {c["id"]: c for c in after["semantics"]["cases"]}
    case_changes = []
    for case_id in sorted(left.keys() | right.keys()):
        changes = differences(left.get(case_id), right.get(case_id))
        if changes:
            for change in changes:
                change["category"] = category(change)
                if change["category"] == "PARSER_ACTION_CLASSIFICATION":
                    change["action_escalation"] = (change["before"] in {"IGNORE", "AMBIGUOUS"}
                        and change["after"] in {"ENTRY", "ADD", "TRIM", "EXIT", "STOP"})
            case_changes.append({"case_id": case_id, "changes": changes})
    counts = Counter(change["category"] for case in case_changes for change in case["changes"])
    result = {"before_sha": before["source"]["head_sha"], "after_sha": after["source"]["head_sha"],
        "same_probe": same_probe, "same_corpus": same_corpus, "stable_sources": stable_sources,
        "semantic_cases_complete": complete,
        "before_incomplete_cases": before["semantics"].get("incomplete_cases", []),
        "after_incomplete_cases": after["semantics"].get("incomplete_cases", []),
        "status": "NOT_COMPARABLE" if not (same_probe and same_corpus and stable_sources) else
                  "CHANGED_REVIEW_REQUIRED" if case_changes else
                  "IDENTICAL_WITH_INCOMPLETE_CASES" if not complete else "IDENTICAL_ON_THIS_CORPUS",
        "case_count_before": len(left), "case_count_after": len(right),
        "changed_cases": len(case_changes), "category_counts": dict(counts), "cases": case_changes,
        "before_semantic_sha256": before["semantics"]["canonical_sha256"],
        "after_semantic_sha256": after["semantics"]["canonical_sha256"],
        "limits": "Differences are classified, never auto-approved. Equality covers this finite corpus only."}
    write_json(args.out, result)
    print(json.dumps({k: v for k, v in result.items() if k != "cases"}, sort_keys=True))
    return 0


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = parser.add_subparsers(dest="command", required=True)
    capture_parser = sub.add_parser("capture")
    capture_parser.add_argument("--repo", type=Path, required=True)
    capture_parser.add_argument("--out", type=Path, required=True)
    capture_parser.add_argument("--golden", type=Path)
    capture_parser.add_argument("--mode", choices=("semantics", "benchmarks", "all"), default="semantics")
    capture_parser.add_argument("--samples", type=int, default=320)
    compare_parser = sub.add_parser("compare")
    compare_parser.add_argument("--before", type=Path, required=True)
    compare_parser.add_argument("--after", type=Path, required=True)
    compare_parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    return capture(args) if args.command == "capture" else compare(args)


if __name__ == "__main__":
    raise SystemExit(main())
